<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                <h1>Modificar Sucursal</h1>
                </div>
                <div class="col-sm-6">

                </div>
            </div>
        </div><!-- /.container-fluid -->


        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <div class="card card-info">
                    <div class="card-header">
                        <h3 class="card-title">Sucursal</h3>
                    </div>
                    <!-- /.card-header -->
                    <!-- form start -->
                    <div class="card-body">
                        <form action="<?php echo e(route('Sucursal.update', [$sucursal->id_sucursal])); ?>" method="POST" class="form-horizontal" >
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="form-group row">
                                <label for="sucursal" class="col-sm-1 col-form-label">Nombre:</label>
                                <div class="col-sm-3">
                                    <input type="text" name="sucursal" id="sucursal" class="form-control" value="<?php echo e(old('sucursal', $sucursal->sucursal)); ?>">
                                    <?php if($errors->has('sucursal')): ?>
                                        <span class="errormsg"><?php echo e($errors->first('sucursal')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="col-sm-1"></div>
                                <label for="local" class="col-sm-1 col-form-label">Local:</label>
                                <div class="col-sm-3">
                                    <input type="text" name="local" id="local" class="form-control" value="<?php echo e(old('local', $sucursal->local)); ?>">
                                    <?php if($errors->has('local')): ?>
                                        <span class="errormsg"><?php echo e($errors->first('local')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="direccion" class="col-sm-1 col-form-label">Dirección:</label>
                                <div class="col-sm-11">
                                    <input type="text" name="direccion" id="direccion" class="form-control" value="<?php echo e(old('direccion', $sucursal->direccion)); ?>">
                                    <?php if($errors->has('direccion')): ?>
                                        <span class="errormsg"><?php echo e($errors->first('direccion')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <!-- /.card-body -->
                            <div class="card-footer">
                                <input type="submit" value="Modificar" class="btn btn-success float-right modificarSucursal">
                            </div>
                            <!-- /.card-footer -->
                        </form>
                    </div>
                </div>
                <!-- Callback-->
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php elseif(Session::has('message')): ?>
                    <div class="alert alert-success">
                        <ul>
                                <li><?php echo e(Session::has('message')); ?></li>
                        </ul>
                    </div>
                <?php endif; ?>
                <!-- /Callback-->
            </div>
        </section>
        <!-- /.content -->
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\servicio\resources\views/Sucursal/modificarSucursal.blade.php ENDPATH**/ ?>