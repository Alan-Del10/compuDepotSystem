<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
            <h1>Agregar Artículo</h1>
            </div>
            <div class="col-sm-6">

            </div>
        </div>
        </div><!-- /.container-fluid -->


        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <div class="card card-info">
                    <div class="card-header">
                        <h3 class="card-title">Artículo</h3>
                    </div>
                    <!-- /.card-header -->
                    <!-- form start -->
                    <form action="<?php echo e(route('Articulo.store')); ?>" method="POST" class="form-horizontal" id="form">
                        <?php echo csrf_field(); ?>
                        <div class="card-body">
                        <div class="form-group row">
                            <label for="marca" class="col-sm-2 col-form-label">Marca</label>
                            <div class="col-sm-9">
                                <select class="form-control" id="marca" name="marca">
                                    <option value="0">Seleccionar Marca</option>
                                    <?php $__currentLoopData = $marcas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($marca->id_marca); ?>"> <?php echo e($marca->descripcion); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-sm-1">
                                <button type="button" class="btn btn-primary" id="agregarMarca"><i class="fas fa-plus"></i></button>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="modelo" class="col-sm-2 col-form-label">Modelo</label>
                            <div class="col-sm-4">
                                <select class="form-control" id="modelo">
                                    <option value="0">Seleccionar Modelo</option>
                                    <?php $__currentLoopData = $modelos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modelo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($modelo->id_modelo); ?>"><?php echo e($modelo->descripcion); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-sm-1">
                                <button type="button" class="btn btn-primary" id="agregarModelo"><i class="fas fa-plus"></i></button>
                            </div>
                            <label for="capacidad" class="col-sm-1 col-form-label">Capacidad</label>
                            <div class="col-sm-3">
                                <select class="form-control" id="capacidad">
                                    <option value="0">Seleccionar Capacidad</option>
                                    <?php $__currentLoopData = $capacidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $capacidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($capacidad->id_capacidad); ?>"><?php echo e($capacidad->tipo); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-sm-1">
                                <button type="button" class="btn btn-primary" id="agregarCapacidad"><i class="fas fa-plus"></i></button>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="descripcion" class="col-sm-2 col-form-label">Descripción</label>
                            <div class="col-sm-4">
                                <input type="text" class="form-control" id="descripcion" placeholder="Descripción">
                            </div>
                            <label for="costo" class="col-sm-2 col-form-label">Costo Promedio ($)</label>
                            <div class="col-sm-2">
                                <input type="text" class="form-control" id="costo" placeholder="Costo Promedio">
                            </div>
                            <label for="peso" class="col-sm-1 col-form-label">Peso(Kg)</label>
                            <div class="col-sm-1">
                                <input type="text" class="form-control" id="peso" placeholder="Peso">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="largo" class="col-sm-2 col-form-label">Largo(m)</label>
                            <div class="col-sm-2">
                                <input type="text" class="form-control" id="largo" placeholder="Largo">
                            </div>
                            <div class="col-sm-1"></div>
                            <label for="alto" class="col-sm-1 col-form-label">Alto(m)</label>
                            <div class="col-sm-2">
                                <input type="text" class="form-control" id="alto" placeholder="Alto">
                            </div>
                            <div class="col-sm-1"></div>
                            <label for="ancho" class="col-sm-1 col-form-label">Ancho(m)</label>
                            <div class="col-sm-2">
                                <input type="text" class="form-control" id="ancho" placeholder="Ancho">
                            </div>
                        </div>
                        <!-- /.card-body -->
                        <div class="card-footer">
                            <input type="submit" value="Agregar" class="btn btn-success float-right agregarArticulo">
                        </div>
                        <!-- /.card-footer -->
                    </form>
                </div>

            </div>
            <!-- Callback-->
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php elseif(Session::has('message')): ?>
                <div class="alert alert-success">
                    <ul>
                        <?php echo e(Session::get('success')); ?>

                    </ul>
                </div>
            <?php endif; ?>
        <!-- /Callback-->
        </section>
        <!-- /.content -->
    </section>
    <script>
        var modelos =  <?php echo json_encode($modelos, 15, 512) ?>;
        //Cargar modelos dependiendo de la marca
        $('#marca').change(function(){
            if($(this).val() != null){
                $('#modelo option').remove();
                modelos.forEach(modelo => {
                    if($(this).val() == modelo.id_marca){
                        console.log(modelo);
                        $('#modelo').append('<option value="'+modelo.id_modelo+'">'+modelo.descripcion+'</option>');
                    }
                });
            }
        });
        //Agregar marca
        $('#agregarMarca').on('click', function() {
            Swal.fire({
                title: "Agregar Marca",
                html: '' +
                            '<div class="form-group row">' +
                            '<div class="col-sm-12">' +
                                '<label for="marcaDescripcion" class="float-left col-form-label">Descripcion</label>' +
                                '<input type="text" class="form-control" id="marcaDescripcion" placeholder="Descripcion">' +
                            '</div>' +
                            '</div>'
                ,
                confirmButtonText: "Agregar",
                showCancelButton: true,
                cancelButtonText: "Cancelar",
                closeOnConfirm: true
            }).then((result) => {
            if(result.isConfirmed){
                marcaDescripcion = document.getElementById('marcaDescripcion').value;
                if(marcaDescripcion != null || marcaDescripcion != ''){
                    $.ajax({
                        type: "get",
                        url: "<?php echo e(route('agregarMarca')); ?>",
                        data:{'marcaDescripcion' : marcaDescripcion},
                        success: function(data) {
                        console.log(data);
                        if(data == 2){
                            swal.fire("Error", "Marca Existente NO Puedes Agregar La Misma!", "error");
                        }else if(data == 1){
                            swal.fire("Logrado", "La Marca Se Registro Correctamente!", "success");
                            $('.swal2-confirm').click(function(){
                                location.reload();
                            });
                        }else{
                            swal.fire("Informativo", data, "info");
                        }
                        },
                        error: function(data) {
                            console.log(data);
                            Swal.fire("Oops", "No se pudo agregar revisa correctamente la info!", "error");
                        }
                    });
                }else{
                    Swal("Oops", "No puede ir vacio!", "error");
                        return false;
                    }
                }
            });


            //validacion del modal
            $('#marcaDescripcion').on('input', function() {
                var input=$(this);
                var re = /[^A-Za-z0-9- ]+$/;
                var testing=re.test(input.val());
                if(testing === true){
                    input.removeClass("is-valid").addClass("is-invalid");
                    input.parent().find('.error').remove();
                    input.parent().append('<div class="invalid-feedback error">Error solo se permiten Letras,Números y Guíones!</div>');
                }
                else{
                    input.removeClass("is-invalid").addClass("is-valid");
                    input.parent().find('.error').remove();
                }
                this.value = this.value.replace(/[^A-Za-z0-9- ]+$/g,'').toUpperCase();
            });
        });
        //Agregar  modelo
        $('#agregarModelo').on('click', function() {
            //sacar una cadena de options para el sweet alert
            var cadenaOption = '<select class="form-control" id="marcaOption">';//inicializo variable para el options del sweet alert
            marcas.forEach(marca => {
                cadenaOption = cadenaOption +'<option value="'+marca.id_marca+'">'+marca.descripcion+'</option>';
            });
            cadenaOption = cadenaOption + '</select>';

            Swal.fire({
                title: "Agregar Modelo",
                html: '' +
                            '<div class="form-group row">' +
                            '<div class="col-sm-12">' +
                                '<label for="modeloDescripcion" class="float-left col-form-label">Descripcion</label>' +
                                '<input type="text" class="form-control" id="modeloDescripcion" placeholder="Descripcion">' +
                            '</div>' +
                            '<div class="col-sm-12">' +
                                '<label for="marcaDescripcion" class="float-left col-form-label">Marca</label>' +
                                ''+cadenaOption+'' +
                            '</div>' +
                            '</div>'
                ,
                confirmButtonText: "Agregar",
                showCancelButton: true,
                cancelButtonText: "Cancelar",
                closeOnConfirm: true
            }).then((result) => {
                if(result.isConfirmed){

                    modeloDescripcion = document.getElementById('modeloDescripcion').value;
                    marcaOption = document.getElementById('marcaOption').value;

                    if(modeloDescripcion != null || modeloDescripcion != ''){
                        $.ajax({
                            type: "get",
                            url: "<?php echo e(route('agregarModelo')); ?>",
                            data:{'modeloDescripcion' : modeloDescripcion,'marcaOption' : marcaOption },
                            success: function(data) {
                                console.log(data);
                                if(data == 2){
                                    swal.fire("Error", "Modelo Existente NO Puedes Agregar La Misma!", "error");
                                }else if(data == 1){
                                    swal.fire("Logrado", "El Modelo Se Registro Correctamente!", "success");
                                    $('.swal2-confirm').click(function(){
                                    location.reload();
                                    });
                                }else{
                                    swal.fire("Informativo", data, "info");
                                }
                            },
                            error: function(data) {
                                console.log(data);
                                Swal.fire("Oops", "No se pudo agregar revisa correctamente la info!", "error");
                            }
                        });
                    }else{
                        Swal("Oops", "No puede ir vacio!", "error");
                        return false;
                    }
                }
            });


            //validacion del modal
            $('#modeloDescripcion').on('input', function() {
                var input=$(this);
                var re = /[^A-Za-z0-9- ]+$/;
                var testing=re.test(input.val());
                if(testing === true){
                    input.removeClass("is-valid").addClass("is-invalid");
                    input.parent().find('.error').remove();
                    input.parent().append('<div class="invalid-feedback error">Error solo se permiten Letras,Números y Guíones!</div>');
                }
                else{
                    input.removeClass("is-invalid").addClass("is-valid");
                    input.parent().find('.error').remove();
                }

                this.value = this.value.replace(/[^A-Za-z0-9- ]+$/g,'').toUpperCase();

            });
        });
    </script>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\servicio\resources\views/Articulo/agregarArticulo.blade.php ENDPATH**/ ?>