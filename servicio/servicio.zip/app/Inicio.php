<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Inicio extends Model
{
    
}
